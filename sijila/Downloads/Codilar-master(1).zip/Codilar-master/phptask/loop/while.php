<?php
$count=0;
while($count<=5)
{
echo $count."<br>";
$count++;
}
?>

