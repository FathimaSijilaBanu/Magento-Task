<!DOCTYPE html>
<body>
<form method="post" action="switchresult.php">
<input type="text" placeholder="Enter your favourite color" name="favcolor"/><br/>
<input type="submit" value="Submit">
</form>
