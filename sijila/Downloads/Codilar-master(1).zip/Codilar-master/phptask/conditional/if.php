<?php
$n=(float)readline("Enter a number:");
if ($n>0)
echo "$n is a positive number\n";
elseif ($n<0)
echo "$n is a negetive number\n";
else
echo "The number is zero\n";
?>
