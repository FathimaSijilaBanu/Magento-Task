<?php

namespace Codilar\CustomTable\Model\ResourceModel\VendorInfo;

use Magento\Framework\ObjectManagerInterface;

class CollectionFactory
{
    protected $objectManager;
    protected $instanceName;

    public function __construct(ObjectManagerInterface $objectManager, $instanceName = '\\Codilar\\CustomTable\\Model\\ResourceModel\\VendorInfo\\VendorInfoCollection')
    {
        $this->objectManager = $objectManager;
        $this->instanceName = $instanceName;
    }

    public function create(array $data = [])
    {
        return $this->objectManager->create($this->instanceName, $data);
    }
}
