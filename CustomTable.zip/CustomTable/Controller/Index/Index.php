<?php
namespace Codilar\CustomTable\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Codilar\CustomTable\Api\VendorInfoRepositoryInterface;

class Index extends Action
{
    protected $resultPageFactory;
    protected $vendorInfoRepository;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        VendorInfoRepositoryInterface $vendorInfoRepository
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->vendorInfoRepository = $vendorInfoRepository;
        parent::__construct($context);
    }

    public function execute()
    {
        $vendorInfoCollection = $this->vendorInfoRepository->getAll();
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->getTitle()->set(__('Vendor Info'));
        $block = $resultPage->getLayout()->getBlock('content');
        if ($block) {
            $block->setData('vendor_info_collection', $vendorInfoCollection);
        }
        return $resultPage;
    }
    
}
