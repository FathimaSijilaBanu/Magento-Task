<?php
namespace Codilar\CustomTable\Model;

use Codilar\CustomTable\Api\Data\VendorInfoInterface;
use Codilar\CustomTable\Api\Data\VendorInfoInterfaceFactory;
use Codilar\CustomTable\Api\Data\VendorInfoSearchResultsInterfaceFactory;
use Codilar\CustomTable\Api\VendorInfoRepositoryInterface;
use Codilar\CustomTable\Model\ResourceModel\VendorInfo as VendorInfoResource;
use Codilar\CustomTable\Model\ResourceModel\VendorInfo\CollectionFactory as VendorInfoCollectionFactory;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchResultsInterface;
use Magento\Framework\Api\SearchResultsInterfaceFactory;

class VendorInfoRepository implements VendorInfoRepositoryInterface
{
    /**
     * @var VendorInfoResource
     */
    protected $resource;

    /**
     * @var VendorInfoInterfaceFactory
     */
    protected $vendorInfoFactory;

    /**
     * @var VendorInfoSearchResultsInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * @var VendorInfoCollectionFactory
     */
    protected $vendorInfoCollectionFactory;

    /**
     * @var CollectionProcessorInterface
     */
    protected $collectionProcessor;

    public function __construct(
        VendorInfoResource $resource,
        VendorInfoInterfaceFactory $vendorInfoFactory,
        SearchResultsInterfaceFactory $searchResultsFactory,
        VendorInfoCollectionFactory $vendorInfoCollectionFactory,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource = $resource;
        $this->vendorInfoFactory = $vendorInfoFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->vendorInfoCollectionFactory = $vendorInfoCollectionFactory;
        $this->collectionProcessor = $collectionProcessor;
    }

    /**
     * Save vendor info.
     *
     * @param VendorInfoInterface $vendorInfo
     * @return VendorInfoInterface
     * @throws \Magento\Framework\Exception\CouldNotSaveException
     */
    public function save(VendorInfoInterface $vendorInfo)
    {
        try {
            $this->resource->save($vendorInfo);
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\CouldNotSaveException(__($exception->getMessage()));
        }
        return $vendorInfo;
    }

    /**
     * Retrieve vendor info.
     *
     * @param int $vendorInfoId
     * @return VendorInfoInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function getById($vendorInfoId)
    {
        $vendorInfo = $this->vendorInfoFactory->create();
        $this->resource->load($vendorInfo, $vendorInfoId);
        if (!$vendorInfo->getId()) {
            throw new \Magento\Framework\Exception\NoSuchEntityException(__('Vendor Info with id "%1" does not exist.', $vendorInfoId));
        }
        return $vendorInfo;
    }

    /**
     * Delete vendor info.
     *
     * @param VendorInfoInterface $vendorInfo
     * @return bool true on success
     * @throws \Magento\Framework\Exception\CouldNotDeleteException
     */
    public function delete(VendorInfoInterface $vendorInfo)
    {
        try {
            $this->resource->delete($vendorInfo);
        } catch (\Exception $exception) {
            throw new \Magento\Framework\Exception\CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }

    public function getAll()
    {
        $collection = $this->vendorInfoCollectionFactory->create();
        return $collection->getItems();
    }
}
