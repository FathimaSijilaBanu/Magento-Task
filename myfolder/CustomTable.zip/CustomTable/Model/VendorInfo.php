<?php
namespace Codilar\CustomTable\Model;

use Magento\Framework\DataObject\IdentityInterface;
use Codilar\CustomTable\Api\Data\VendorInfoInterface;

class VendorInfo extends \Magento\Framework\DataObject implements VendorInfoInterface, IdentityInterface
{
    const CACHE_TAG = 'vendor_info';

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        $this->_init('Codilar\CustomTable\Model\ResourceModel\VendorInfo');
    }

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getData(self::ID);
    }

    /**
     * @inheritDoc
     */
    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getData(self::NAME);
    }

    /**
     * @inheritDoc
     */
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }

    /**
     * @inheritDoc
     */
    public function getDescription()
    {
        return $this->getData(self::DESCRIPTION);
    }

    /**
     * @inheritDoc
     */
    public function setDescription($description)
    {
        return $this->setData(self::DESCRIPTION, $description);
    }

    /**
     * @inheritDoc
     */
    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

    /**
     * @inheritDoc
     */
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    /**
     * @inheritDoc
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
}
